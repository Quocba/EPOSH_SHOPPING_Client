/* eslint-disable react-hooks/exhaustive-deps */
import React from "react";
import AdminPage from "./Admin.Page";

const AdminContainer: React.FC<{}> = () => {
  return <AdminPage />;
};

export default AdminContainer;
